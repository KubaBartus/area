package selenium.modules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Setts {

    private WebDriver driver;


    public Setts()
    {
        this.driver = new ChromeDriver();
    }

    public WebDriver getDriver(){
        if (driver == null){
            driver = new ChromeDriver();
            return driver;
        }else{
            return driver;
        }
    }

}

