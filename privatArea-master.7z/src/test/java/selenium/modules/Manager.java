package selenium.modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Manager extends Pracownik {
    private String domena = "http://localhost:8080/login";
    String itemCode = "12345678912";
    String amount = "500";
    public void addItem()
    {
        WebElement barcode = getDriver().findElement(By.id("itemCode"));
        WebElement name = getDriver().findElement(By.id("itemName"));
        WebElement amount = getDriver().findElement(By.id("itemamo"));
        WebElement weight = getDriver().findElement(By.id("itemweight"));
        WebElement dimension_x = getDriver().findElement(By.id("itemdimx"));
        WebElement dimension_y = getDriver().findElement(By.id("itemdimy"));
        WebElement dimension_z = getDriver().findElement(By.id("itemdimz"));
        WebElement location_x = getDriver().findElement(By.id("itemlocationx"));
        WebElement location_y = getDriver().findElement(By.id("itemlocationy"));
        WebElement location_z = getDriver().findElement(By.id("itemlocationz"));
        WebElement submit = getDriver().findElement(By.xpath("/html/body/div/form/input[2]"));
        barcode.sendKeys(itemCode);
        name.sendKeys("IPHONE 15");
        amount.sendKeys("100");
        weight.sendKeys("20");
        dimension_x.sendKeys("5");
        dimension_y.sendKeys("5");
        dimension_z.sendKeys("5");
        location_x.sendKeys("5");
        location_y.sendKeys("5");
        location_z.sendKeys("5");
        submit.click();
    }
    public void checkItem()
    {
      boolean success = getDriver().getPageSource().contains(itemCode);
      boolean ammount = getDriver().getPageSource().contains(amount);
      if(ammount == true & success == true) System.out.println("Success!");
    }

}
