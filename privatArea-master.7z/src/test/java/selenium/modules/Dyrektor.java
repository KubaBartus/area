package selenium.modules;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;

public class Dyrektor extends Pracownik {

    private ArrayList<String> informationUserTest;
    private ArrayList<String> userElements;
    private String path;
    private String clickName;
    private String domena = "http://localhost:8080/login";

    public Dyrektor() {
    }

    public void addUser()
    {
        WebElement email = getDriver().findElement(By.id("email"));
        WebElement username = getDriver().findElement(By.id("username"));
        WebElement password = getDriver().findElement(By.id("password"));
        WebElement name = getDriver().findElement(By.id("worker.name"));
        WebElement surrname = getDriver().findElement(By.id("worker.surrname"));
        WebElement address = getDriver().findElement(By.id("worker.address"));
        WebElement pesel = getDriver().findElement(By.id("worker.pesel"));
        WebElement phone = getDriver().findElement(By.id("worker.phoneNumber"));
        WebElement title = getDriver().findElement(By.id("worker.title"));
        WebElement salary = getDriver().findElement(By.id("worker.salary"));
        WebElement submit = getDriver().findElement(By.xpath("/html/body/div/form/input[2]"));
        email.sendKeys("email@o2.pl");
        username.sendKeys("pracownik");
        password.sendKeys("pracownik");
        name.sendKeys("test");
        surrname.sendKeys("test");
        address.sendKeys("test");
        pesel.sendKeys("12312312311");
        phone.sendKeys("123123123");
        title.sendKeys("pracownik1");
        salary.sendKeys("1232");
        submit.click();
    }
}
