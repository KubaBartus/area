package selenium.modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;

public class Pracownik extends Setts {

    private ArrayList<String> informationUserTest;
    private ArrayList<String> userElements;
    private String domena = "http://localhost:8080/login";
    private String path;
    private String clickName;

    public Pracownik() {
    }


    public void dataConf() {
        getDriver().get(domena);
    }


    public void testFunctional(String loginData, String passwordData) {
        WebElement username = getDriver().findElement(By.id("username"));
        WebElement password = getDriver().findElement(By.id("password"));
        WebElement login = getDriver().findElement(By.xpath("/html/body/div/div/form/input[4]"));
        username.sendKeys(loginData);
        password.sendKeys(passwordData);
        login.click();
    }
    public void goToNextSection(String navName, String zakladkaName)
    {
        WebElement nav = getDriver().findElement(By.xpath(navName));
        nav.click();
        WebElement zakladka = getDriver().findElement(By.xpath(zakladkaName));
        zakladka.click();
    }
    public boolean tryEndpoint()
    {
        String endpoint = "http://localhost:8080/client/new";
        boolean success;
        String dangerText = "/html/body/div/div/div/div/h3";
        getDriver().get(endpoint);
            if(getDriver().findElement(By.xpath(dangerText)).isDisplayed())
            {
               success = true;
            } else success = false;
            return success;
    }
}
