package selenium;


import io.cucumber.java.After;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import selenium.modules.Dyrektor;
import selenium.modules.Manager;
import selenium.modules.Pracownik;


import java.util.ArrayList;

public class ManageArea {
    private Dyrektor dyrektorTest = new Dyrektor();
    private Manager managerTest = new Manager();
    private Pracownik pracownikTest = new Pracownik();
    @BeforeAll
    public static void configuration()
    {
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
    }
    @Test
    public void testWorkerRole()
    {
        pracownikTest.dataConf();
        pracownikTest.testFunctional("kuba","1234");
        pracownikTest.tryEndpoint();

    }
    @Test
    public void testDyrektorRole()
    {
        dyrektorTest.dataConf();
        dyrektorTest.testFunctional("Dyrektor1","admin");
        dyrektorTest.goToNextSection("/html/body/header[2]/div/div[2]/div/div[1]/div/a[2]","/html/body/header[2]/div/div[2]/div/div[1]/div/div/a[3]");
        dyrektorTest.addUser();
    }
    @Test
    public void testItemSection()
    {
        managerTest.dataConf();
        managerTest.testFunctional("Dyrektor1","admin");
        managerTest.goToNextSection("/html/body/header[2]/div/div[2]/div/div[4]/div/a","/html/body/header[2]/div/div[2]/div/div[4]/div/div/a[2]");
        managerTest.addItem();
        managerTest.goToNextSection("/html/body/header[2]/div/div[2]/div/div[4]/div/a","/html/body/header[2]/div/div[2]/div/div[4]/div/div/a[1]");
        managerTest.checkItem();
    }

}