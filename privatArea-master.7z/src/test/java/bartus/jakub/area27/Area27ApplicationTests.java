package bartus.jakub.area27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Area27ApplicationTests {

    @Test
    void contextLoads() {
    }

}
