function isEmailUnique(form)
{
    url = "[[@{/users/isUnique_email}]]";
    userEmail = $("#email").val();
    csrf = $("input[name='_csrf']").val();
    params = {email: userEmail, _csrf: csrf};
    $.post(url, params, function(response) {
        alert("Response from server:");
    });
    return false;
}