function isAlert(form)
{
    url = "[[@{/users/isUsernameOK}]]";
    userUsername = $("#username").val();
    csrf = $("input[name='_csrf']").val();
    params = {username: userUsername, _csrf: csrf};
    $.post(url, params, function(response) {
        alert("Invalid Username Or Password");
    });
    return false;
}