package bartus.jakub.area27.user;

import bartus.jakub.area27.task.Task;
import bartus.jakub.area27.worker.Worker;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends PagingAndSortingRepository<User, Long> {

    Optional<User> findByUsername(String username);

    @Query("SELECT u FROM User u WHERE u.email = :email OR u.username = :username")
    User getUserByEmail(@Param("email") String email, @Param("username") String username);
    @Query("SELECT u FROM User u WHERE u.username = :username")
    User loginValidation(@Param("username") String username);

    Iterable<User> findAll(Sort sort);
    Page<User> findAll(Pageable pageable);

}
