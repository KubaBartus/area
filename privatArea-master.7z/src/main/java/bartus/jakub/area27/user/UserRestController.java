package bartus.jakub.area27.user;


import bartus.jakub.area27.departament.DepartamentService;
import bartus.jakub.area27.role.RoleService;
import bartus.jakub.area27.task.TaskService;
import bartus.jakub.area27.worker.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@RestController
public class UserRestController {

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private WorkerService workerService;
    @Autowired
    private DepartamentService departamentService;

    @GetMapping("/user/{username}/{password}")
    public boolean userValidation(@PathVariable("username") String username, @PathVariable("password") String password)
    {
       return userService.userValidation(username,password);
    }

    @GetMapping("/validation/{email}/{username}")
    public boolean isEmailOrUsernameExists(@PathVariable("email") String email, @PathVariable("username") String username)
    {
        return userService.isEmailOrUsernameExists(email,username);
    }

    //@GetMapping("/user/delete/{id}")
    public String deleteUser(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {  try {
        userService.delete(id);
        redirectAttributes.addFlashAttribute("message", "The user ID" + id + "has been deleted successful");
        return "user/edit-users";
    }catch(Exception ex)
    {
        redirectAttributes.addFlashAttribute(("message"), ex.getMessage());
        return "redirect:/ user/edit-users";
    }
    }



}
