package bartus.jakub.area27.user;

import bartus.jakub.area27.worker.Worker;
import bartus.jakub.area27.worker.WorkerService;
import bartus.jakub.area27.departament.Departament;
import bartus.jakub.area27.departament.DepartamentService;
import bartus.jakub.area27.role.Role;
import bartus.jakub.area27.role.RoleService;
import bartus.jakub.area27.task.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private WorkerService workerService;
    @Autowired
    private DepartamentService departamentService;
    @Autowired
    private UserRepository repository;
    @Autowired
    private UserService service;

    private boolean loggedIn;

    //panel uzytkownika
    @GetMapping("/user-page")
    public String user_page(Model model)
    {
        User user = new User();
        model.addAttribute("user", user);
        return "user/user-page";
    }

    private String path = "panel/user/edit-user";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber,@Param("sortField") String sortField,
                          @Param("sortDir") String sortDir)
    {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }

    @GetMapping("/new")
    public String addUser(Model model)
    {
        model.addAttribute("user",new User());
        model.addAttribute("worker", new Worker());
        List<Role> listRoles = roleService.listAllRoles();
        model.addAttribute("listRoles", listRoles);
        List<Departament> listDepartament = departamentService.listAll();
        model.addAttribute("listDepartament", listDepartament);
        return "user/new-user";
    }

    @PostMapping("/save")
    public String saveUser(User user)
    {
        userService.addUser(user);
        return "redirect:/user/edit-users";
    }

    @GetMapping("/account/edit/{id}")
    public String editUser(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {
        model.addAttribute("user",userService.get(id));
        redirectAttributes.addFlashAttribute("message", "The user ID" + id + "has been eddited successful");
        return "user/edit-account";
    }

    @GetMapping("/person/edit/{id}")
    public String editThisUser(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {
        model.addAttribute("user",userService.get(id));
        redirectAttributes.addFlashAttribute("message", "The user ID" + id + "has been eddited successful");
        return "user/edit-account";
    }


    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {
        try {
            userService.delete(id);
            return "user/edit-users";
        }   catch(Exception ex)
        {
            redirectAttributes.addFlashAttribute(("message"), ex.getMessage());
            return "redirect:/ user/edit-users";
        }
    }
}
