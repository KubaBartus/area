package bartus.jakub.area27.user;


import bartus.jakub.area27.configuration.PagingAndSorting;
import bartus.jakub.area27.role.Role;
import bartus.jakub.area27.task.Task;
import bartus.jakub.area27.worker.Worker;
import bartus.jakub.area27.worker.WorkerRepository;
import bartus.jakub.area27.worker.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.NullLiteral;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements PagingAndSorting {

    private UserRepository userRepo;
    private PasswordEncoder passwordEncoder;


    public UserService(UserRepository userRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }


    public void delete(Long id)
    {
        userRepo.deleteById(id);
    }

    public void addUser(User user) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userRepo.save(user);
    }

    public void createSuperUser()
    {
        User user = new User(1L, "area2","admin@area27.pl","admin", new Role(5), new Worker());
        addUser(user);
    }

    public void editUser(User user) {
        userRepo.save(user);
    }
    public List<User> listAll()
    {
        return (List<User>) userRepo.findAll();
    }
    public Optional<User> get(Long id)
    {
        return userRepo.findById(id);
    }

    public boolean userValidation(String username,String password)
    {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        User user = userRepo.loginValidation(username);
        if(username.equals(user.getUsername()) && encoder.matches(password,user.getPassword()))
        {
            return true;
        }
           return false;
    }

    public boolean isEmailOrUsernameExists(String email,String username) {
        try {
            User user = userRepo.getUserByEmail(email,username);
            if (email.equals(user.getEmail()) || username.equals(user.getUsername())) {
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    return false;
}}
