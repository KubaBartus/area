package bartus.jakub.area27.worker;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WorkerRepository extends JpaRepository<Worker, Long> {
    @Query("SELECT w FROM Worker w WHERE w.pesel = :pesel")
    Worker peselValidation(@Param("pesel") Long pesel);
    Optional<Worker> findByName(String name);



}
