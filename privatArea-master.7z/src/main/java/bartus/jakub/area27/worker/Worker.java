package bartus.jakub.area27.worker;


import bartus.jakub.area27.departament.Departament;
import bartus.jakub.area27.schedule.Schedule;
import bartus.jakub.area27.task.Task;
import bartus.jakub.area27.user.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
public class Worker {

    public Worker()
    {

    }
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "worker_id", nullable = false)
    private Long id;
    private String title;
    private Double salary;

    @Column(unique=true)
    private Long pesel;
    private String address;
    private String name;
    private String surrname;

    @Column(unique=true)
    private String phoneNumber;

    @OneToOne(mappedBy="worker")
    private User user;

    @ManyToOne
    @JoinColumn(name = "departament_id")
    private Departament departament;

    @ManyToMany(mappedBy = "scheduleWorkers")
    Set<Schedule> schedules;
}
