package bartus.jakub.area27.worker;

import bartus.jakub.area27.departament.Departament;
import bartus.jakub.area27.departament.DepartamentService;
import bartus.jakub.area27.role.Role;
import bartus.jakub.area27.role.RoleService;
import bartus.jakub.area27.task.Task;
import bartus.jakub.area27.task.TaskService;
import bartus.jakub.area27.user.User;
import bartus.jakub.area27.user.UserRepository;
import bartus.jakub.area27.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/worker")
public class WorkerController {

    @Autowired
    WorkerService workerService;
    @Autowired
    TaskService taskService;

    @GetMapping("/addTask/{id}")
    public String editUser(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {
        model.addAttribute("worker",workerService.get(id));
        model.addAttribute("taskList", taskService.listAll());
        return "/user/task-per-usr";
    }


}
