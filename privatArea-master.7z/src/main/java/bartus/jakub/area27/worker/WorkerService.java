package bartus.jakub.area27.worker;

import bartus.jakub.area27.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WorkerService {

    @Autowired
    WorkerRepository workerRepo;

    public void addWorker(Worker worker) {
        workerRepo.save(worker);
    }

    public Optional<Worker> get(Long id)
    {
        return workerRepo.findById(id);
    }
    public List<Worker> listAll()
    {
        return (List<Worker>) workerRepo.findAll();
    }
    public boolean isPeselExists(Long pesel) {
            Worker worker = workerRepo.peselValidation(pesel);
            try{
            if (pesel.equals(worker.getPesel())) {
                return true;
            } }catch(Exception e)
            {
                return false;
            }
            return false;
}
}
