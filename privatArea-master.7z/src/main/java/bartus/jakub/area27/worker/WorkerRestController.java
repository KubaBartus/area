package bartus.jakub.area27.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WorkerRestController {
    @Autowired
    private WorkerService workerService;

    @GetMapping("/worker/{pesel}")
    public boolean userValidation(@PathVariable("pesel") Long pesel)
    {
        return workerService.isPeselExists(pesel);
    }
}
