package bartus.jakub.area27.client;


import bartus.jakub.area27.configuration.PagingAndSorting;
import bartus.jakub.area27.departament.Departament;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService implements PagingAndSorting {

    @Autowired
    ClientRepository clientRepository;

    public void addClient(Client client) {
        clientRepository.save(client);
    }
    public List<Client> listAll()
    {
        return (List<Client>) clientRepository.findAll();
    }

    public boolean isExist(Client client)
    {
        boolean success;
        if (!clientRepository.findByName(client.getName()).isPresent())
        {
            addClient(client);
            success = true;
        }else {
            success = false;
        }
        return success;
    }
    public void delete(Long id)
    {
        clientRepository.deleteById(id);
    }

}
