package bartus.jakub.area27.client;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "client_id", nullable = false, unique = true)
    private Long id;
    @Column(columnDefinition = "varchar(255) default 'Empty'", unique = true)
    private String name;
    @Column(name = "typ_klienta", nullable = false, unique = true)
    private String clientType;


}
