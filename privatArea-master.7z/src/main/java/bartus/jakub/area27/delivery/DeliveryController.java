package bartus.jakub.area27.delivery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/delivery")
public class DeliveryController {

    @Autowired
    DeliveryService service;
    @Autowired
    DeliveryRepository repository;

    @GetMapping("/new")
    public String addDelivery(Model model)
    {
        model.addAttribute("delivery",new Delivery());
        return "panel/delivery/add-delivery";
    }

    private String path = "panel/delivery/edit-delivery";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber, @Param("sortField") String sortField,
                          @Param("sortDir") String sortDir)
    {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }

    @PostMapping("/save")
    public String save(Delivery delivery, Model model,BindingResult result) {
        ObjectError error = new ObjectError("error", "err");
        boolean isExist = service.isExist(delivery);
        if (!isExist) {
            result.addError(error);
            model.addAttribute("error", result);
            return "panel/delivery/add-delivery";
        }
        return "main_page/index";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") Long id, Model model, BindingResult result) {
        ObjectError error = new ObjectError("error", "err");
        try {
            repository.deleteById(id);
            result.addError(error);
            model.addAttribute("error", "error");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "panel/delivery/edit-delivery";
    }
}
