package bartus.jakub.area27.delivery;


import bartus.jakub.area27.client.Client;
import bartus.jakub.area27.enums.DeliveryType;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
public class Delivery {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "delivery_id", nullable = false)
    private Long id;
    private Date date;
    private String name;
    private DeliveryType deliveryType;

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;

}
