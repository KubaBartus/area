package bartus.jakub.area27.delivery;


import bartus.jakub.area27.configuration.PagingAndSorting;
import bartus.jakub.area27.departament.Departament;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeliveryService implements PagingAndSorting {

    @Autowired
    DeliveryRepository deliveryRepository;

    public void addDelivery(Delivery delivery) {
        deliveryRepository.save(delivery);
    }
    public List<Delivery> listAll()
    {
        return (List<Delivery>) deliveryRepository.findAll();
    }
    public boolean isExist(Delivery delivery)
    {
        boolean success;
        if (!deliveryRepository.findByName(delivery.getName()).isPresent())
        {
            addDelivery(delivery);
            success = true;
        }else {
            success = false;
        }
        return success;
    }
    public void delete(Long id)
    {
        deliveryRepository.deleteById(id);
    }
}
