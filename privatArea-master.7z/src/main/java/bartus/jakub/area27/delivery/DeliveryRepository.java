package bartus.jakub.area27.delivery;


import bartus.jakub.area27.departament.Departament;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DeliveryRepository extends PagingAndSortingRepository<Delivery,Long> {

    Iterable<Delivery> findAll(Sort sort);
    Page<Delivery> findAll(Pageable pageable);
    Optional<Delivery> findById(Long id);
    Optional<Delivery> findByName(String name);
}
