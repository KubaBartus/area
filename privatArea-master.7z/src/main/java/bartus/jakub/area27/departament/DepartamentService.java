package bartus.jakub.area27.departament;


import bartus.jakub.area27.configuration.PagingAndSorting;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartamentService implements PagingAndSorting {

    @Autowired
    DepartamentRepository departamentRepository;

    public void addDepartament(Departament departament) {
        departamentRepository.save(departament);
    }
    public List<Departament> listAll()
    {
        return (List<Departament>) departamentRepository.findAll();
    }

    public boolean isExist(Departament departament)
    {
       boolean success;
       if (!departamentRepository.findByName(departament.getName()).isPresent())
        {
            addDepartament(departament);
            success = true;
        }else {
           success = false;
       }
       return success;
    }
    public void delete(Long id)
    {
        departamentRepository.deleteById(id);
    }
}
