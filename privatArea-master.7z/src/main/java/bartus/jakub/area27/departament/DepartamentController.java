package bartus.jakub.area27.departament;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/departament")
public class DepartamentController {

    @Autowired
    private DepartamentService service;
    @Autowired
    private DepartamentRepository repository;



    private String path = "panel/departament/edit-departament";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber, @Param("sortField") String sortField,
                          @Param("sortDir") String sortDir) {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }


    @GetMapping("/new")
    public String addDepartament(Model model) {
        model.addAttribute("departament", new Departament());
        return "panel/departament/add-departament";
    }

    @PostMapping("/save")
    public String save(Departament departament, Model model,BindingResult result) {
        ObjectError error = new ObjectError("error", "err");
        boolean isExist = service.isExist(departament);
        if (!isExist) {
            result.addError(error);
            model.addAttribute("error", result);
            return "panel/departament/add-departament";
        }
        return "main_page/index";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") Long id, Model model,BindingResult result) {
        ObjectError error = new ObjectError("error", "err");
        try {
            repository.deleteById(id);
            result.addError(error);
            model.addAttribute("error", "error");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "panel/departament/edit-departament";
    }
}