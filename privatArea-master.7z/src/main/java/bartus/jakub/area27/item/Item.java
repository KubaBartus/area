package bartus.jakub.area27.item;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;


@Entity
@Getter
@Setter
public class Item {
    @Id
    @Column(name = "item_id", nullable = false)
    private Long id;
    private String name;
    private Double weight;
    private Double dimension_x;
    private Double dimension_y;
    private Double dimension_z;
    private int location_x;
    private int location_y;
    private int location_z;
    private Integer amount;
}
