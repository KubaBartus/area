package bartus.jakub.area27.item;

import bartus.jakub.area27.mission.Mission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ItemRepository extends PagingAndSortingRepository<Item,Long> {
    @Modifying
    @Transactional
    @Query("update Item i set i.amount = ?1 where i.id = ?2")
    void setItemAmountById(Integer amount, Long itemId);

    Iterable<Item> findAll(Sort sort);

    Page<Item> findAll(Pageable pageable);
}
