package bartus.jakub.area27.item;


import bartus.jakub.area27.configuration.PagingAndSorting;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService implements PagingAndSorting {

    @Autowired private ItemRepository itemRepo;

    public ItemService(ItemRepository itemRepo)
    {
        this.itemRepo = itemRepo;
    }

    public void addItem(Item item) {
        if(itemRepo.existsById(item.getId()))
        {
             Item tempItem = itemRepo.findById(item.getId()).get();
             int tempAmount = tempItem.getAmount() + item.getAmount();
             itemRepo.setItemAmountById(tempAmount, item.getId());
        }
        else itemRepo.save(item);
    }

    public List<Item> listAll()
    {
        return (List<Item>) itemRepo.findAll();
    }
}
