package bartus.jakub.area27.item;

import bartus.jakub.area27.mission.MissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/item")
public class ItemController {

    @Autowired ItemService service;

    @Autowired
    ItemRepository repository;

    @GetMapping("/new")
    public String addItem(Model model)
    {
        model.addAttribute("item", new Item());
        return "panel/item/add-item";
    }

    @PostMapping("/save")
    public String saveItem(Item item)
    {
        service.addItem(item);
        return "redirect:/";
    }

    private String path = "panel/item/edit-item";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber, @Param("sortField") String sortField,
                          @Param("sortDir") String sortDir)
    {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }

}
