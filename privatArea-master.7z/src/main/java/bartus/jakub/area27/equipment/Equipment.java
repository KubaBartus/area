package bartus.jakub.area27.equipment;

import bartus.jakub.area27.departament.Departament;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
public class Equipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "equipment_id", nullable = false, unique = true)
    private Long id;
    private String name;
    private Integer amount;
    @ManyToOne
    @JoinColumn(name="departament_id", nullable=false)
    private Departament departament;
}
