package bartus.jakub.area27.equipment;

import bartus.jakub.area27.configuration.PagingAndSorting;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipmentService implements PagingAndSorting {
    @Autowired
    EquipmentRepository equipmentRepository;

    public void addEquipment(Equipment equipment) {
        if(equipmentRepository.existsById(equipment.getId()))
        {
            Equipment tempEquipment = equipmentRepository.findById(equipment.getId()).get();
            int tempAmount = tempEquipment.getAmount() + equipment.getAmount();
            equipmentRepository.setEquipmentAmountById(tempAmount, equipment.getId());
        }
        else equipmentRepository.save(equipment);
    }
    public void delete(Long id)
    {
        equipmentRepository.deleteById(id);
    }

    public List<Equipment> listAllEquipment()
    {
        return (List<Equipment>) equipmentRepository.findAll();
    }
}
