package bartus.jakub.area27.equipment;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface EquipmentRepository extends PagingAndSortingRepository<Equipment,Long> {

    @Modifying
    @Transactional
    @Query("update Equipment e set e.amount = ?1 where e.id = ?2")
    void setEquipmentAmountById(Integer amount, Long equipmentId);

    Iterable<Equipment> findAll(Sort sort);
    Page<Equipment> findAll(Pageable pageable);

}
