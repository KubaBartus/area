package bartus.jakub.area27.mission;


import bartus.jakub.area27.client.ClientService;
import bartus.jakub.area27.delivery.DeliveryService;
import bartus.jakub.area27.departament.DepartamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/mission")
public class MissionController {

    @Autowired
    MissionService service;
    @Autowired
    ClientService clientService;

    @Autowired
    DepartamentService departamentService;

    @Autowired
    DeliveryService deliveryService;
    @Autowired
    MissionRepository repository;
    @GetMapping("/new")
    public String addMission(Model model)
    {
        model.addAttribute("mission", new Mission());
        model.addAttribute("deliveryList", deliveryService.listAll());
        model.addAttribute("departamentList", departamentService.listAll());
        model.addAttribute("clientList", clientService.listAll());
        return "panel/mission/add-mission";
    }

    @PostMapping("/save")
    public String saveMission(Mission mission)
    {
        service.addMission(mission);
        return path;
    }

    @RequestMapping("/description/{id}")
    public String describe(@PathVariable(name = "id") Long id, Model model)
    {
        String description = service.getDescription(id);
        model.addAttribute("missionDescription", description);
        return "panel/mission/mission-details";
    }

    private String path = "panel/mission/edit-mission";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber, @Param("sortField") String sortField,
                          @Param("sortDir") String sortDir)
    {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }

}
