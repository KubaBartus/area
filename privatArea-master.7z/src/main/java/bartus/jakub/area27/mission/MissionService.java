package bartus.jakub.area27.mission;



import bartus.jakub.area27.configuration.PagingAndSorting;
import bartus.jakub.area27.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MissionService implements PagingAndSorting {

    @Autowired
    MissionRepository missionRepository;
    public void addMission(Mission mission) {
        missionRepository.save(mission);
    }
    public List<Mission> listAll()
    {
        return (List<Mission>) missionRepository.findAll();
    }
    public String getDescription(Long id)
    {
    Mission mission =  missionRepository.getMissionById(id);
    return mission.getDescription();
    }
}
