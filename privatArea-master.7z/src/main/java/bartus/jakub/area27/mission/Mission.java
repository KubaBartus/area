package bartus.jakub.area27.mission;


import bartus.jakub.area27.client.Client;
import bartus.jakub.area27.delivery.Delivery;
import bartus.jakub.area27.departament.Departament;
import bartus.jakub.area27.enums.IsDone;
import bartus.jakub.area27.task.Task;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.*;

@Entity
@Getter
@Setter
public class Mission {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(columnDefinition = "varchar(255) default 'Empty'")
    private String name;
    @Column(columnDefinition = "varchar(255) default 'Empty'")
    private String description;
    @Column(columnDefinition = "date default '1000-01-01'")
    private Date startDate;
    @Column(columnDefinition = "date default '1000-01-01'")
    private Date endDate;
    private IsDone status;

    @ManyToOne
    @JoinColumn(name="departament_id")
    private Departament departament;

    @ManyToOne
    @JoinColumn(name="client_id")
    private Client client;

    @ManyToOne
    @JoinColumn(name="delivery_id")
    private Delivery delivery;

    public IsDone getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = IsDone.valueOf(status);
    }

    public Client getClient()
    {
        if(client == null)
        {
            client = new Client();
        }
        return client;
    }

    public Delivery getDelivery()
    {
        if(delivery == null)
        {
            delivery = new Delivery();
        }
        return delivery;
    }

}
