package bartus.jakub.area27.configuration;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.PagingAndSortingRepository;




public interface PagingAndSorting {
    default Page<Object> listAll(int pageNumber, String sortField,
                                 String sortDir, PagingAndSortingRepository repository)
    {
        int sizePagination = 5;
        Pageable pageable = PageRequest.of(pageNumber - 1, sizePagination,
                sortDir.equals("asc") ? Sort.by(sortField).ascending()
                        : Sort.by(sortField).descending()
        );
        return repository.findAll(pageable);
    }
}

