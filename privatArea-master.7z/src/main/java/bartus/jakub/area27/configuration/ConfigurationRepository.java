package bartus.jakub.area27.configuration;

import org.hibernate.type.descriptor.sql.TinyIntTypeDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigurationRepository extends JpaRepository<Configuration, Integer> {

}
