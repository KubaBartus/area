package bartus.jakub.area27.configuration;


import org.hibernate.type.descriptor.sql.TinyIntTypeDescriptor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Configuration {
    @Id
    @Column(name = "id", nullable = false)
    private int id;

    Configuration(int id){
        this.id = id;
    }

    Configuration() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
