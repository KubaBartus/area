package bartus.jakub.area27.configuration;

import bartus.jakub.area27.role.RoleService;
import bartus.jakub.area27.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ConfigurationService{

    @Autowired
    RoleService roleService;

    @Autowired
    UserService userService;

    @Autowired
    ConfigurationRepository configurationRepository;
    public void systemInstalling()
    {
        if(!configurationRepository.existsById(1))
        {
            Configuration configuration = new Configuration(1);
            configurationRepository.save(configuration);
            roleService.rolesAdd();
            userService.createSuperUser();
        }

    }

}
