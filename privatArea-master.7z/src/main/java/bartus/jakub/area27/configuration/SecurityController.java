package bartus.jakub.area27.configuration;

import bartus.jakub.area27.user.User;
import bartus.jakub.area27.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class SecurityController implements ErrorController {

    @Autowired
    private UserService userService;

    @Autowired
    ConfigurationService configurationService;

    @Autowired
    EmailService emailService;

    @GetMapping("/login")
    public String loginPage(Model model)
    {
        model.addAttribute("user", new User());
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(auth == null || auth instanceof AnonymousAuthenticationToken)
        {
            return "login_system/login";
        }

        return "/";
    }

    @GetMapping("/logout.success")
    public String logoutPage()
    {
        return "main_page/index";
    }


    //Main Page
    @GetMapping("/")
    public String startPage()
    {
        configurationService.systemInstalling();
        return "main_page/index";
    }

    @RequestMapping("/error")
    public String errorMapping()
    {
        return "main_page/badCredentials";
    }

    @RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo(HttpServletRequest request, HttpServletResponse response){
        HttpSession session= request.getSession(false);
        SecurityContextHolder.clearContext();
        session= request.getSession(false);
        if(session != null) {
            session.invalidate();
        }
        for(Cookie cookie : request.getCookies()) {
            cookie.setMaxAge(0);
        }
        return "logout";
    }
}
