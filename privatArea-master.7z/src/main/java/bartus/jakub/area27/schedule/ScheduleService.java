package bartus.jakub.area27.schedule;

public class ScheduleService {
}
