package bartus.jakub.area27.schedule;


import bartus.jakub.area27.worker.Worker;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
@Entity
public class Schedule {
    @Id
    @Column(name = "schedule_id", nullable = false)
    private Long id;
    private Date dateStart;
    private Date dateEnd;
    private int workHours;
    @ManyToMany
    @JoinTable(
            name = "grafik",
            joinColumns = @JoinColumn(name = "schedule_id"),
            inverseJoinColumns = @JoinColumn(name = "worker_id"))
    Set<Worker> scheduleWorkers;

}
