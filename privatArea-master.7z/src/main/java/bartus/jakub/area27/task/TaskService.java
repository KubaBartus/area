package bartus.jakub.area27.task;

import bartus.jakub.area27.configuration.PagingAndSorting;
import bartus.jakub.area27.mission.Mission;
import bartus.jakub.area27.user.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService implements PagingAndSorting {

    @Autowired TaskRepository taskRepo;

    public void addTask(Task task) {
       taskRepo.save(task);
    }

    public List<Task> listAll()
    {
        return (List<Task>) taskRepo.findAll();
    }

    public String getDescription(Long id)
    {
        Task task =  taskRepo.getTaskById(id);
        return task.getDescription();
    }

}
