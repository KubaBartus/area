package bartus.jakub.area27.task;

import bartus.jakub.area27.enums.IsDone;
import bartus.jakub.area27.item.Item;
import bartus.jakub.area27.mission.Mission;
import bartus.jakub.area27.worker.Worker;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="task_id")
    private Long id;
    private String name;
    private String description;
    private IsDone status;

    @ManyToOne
    @JoinColumn(name = "mission_id")
    Mission mission;

    @ManyToOne
    @JoinColumn(name = "worker_id")
    Worker worker;

    @ManyToOne
    @JoinColumn(name = "item_id")
    Item item;

    public IsDone getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = IsDone.valueOf(status);
    }

    public Mission getMission()
    {
        if(mission == null)
        {
            mission = new Mission();
        }
        return mission;
    }

}
