package bartus.jakub.area27.task;

import bartus.jakub.area27.item.ItemRepository;
import bartus.jakub.area27.item.ItemService;
import bartus.jakub.area27.mission.MissionRepository;
import bartus.jakub.area27.mission.MissionService;
import bartus.jakub.area27.worker.Worker;
import bartus.jakub.area27.worker.WorkerRepository;
import bartus.jakub.area27.worker.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import java.util.List;

@Controller
@RequestMapping("/task")
public class TaskController {


  @Autowired
  private TaskService service;

  @Autowired TaskRepository repository;
  @Autowired
  MissionService missionService;
  @Autowired
  WorkerService workerService;
  @Autowired
  ItemService itemService;

  @Autowired
  TaskService taskService;

  private String path = "panel/task/edit-task";

    @RequestMapping("/edit/page/{pageNum}")
    public String listAll(Model model, @PathVariable(name = "pageNum") int pageNumber,@Param("sortField") String sortField,
                          @Param("sortDir") String sortDir)
    {
        Page<Object> page = service.listAll(pageNumber, sortField, sortDir, repository);
        List<Object> listEntity = page.getContent();
        model.addAttribute("currentPage", pageNumber);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("listEntity", listEntity);
        return path;
    }

    @RequestMapping("/edit")
    public String viewPage(Model model) {
        return listAll(model, 1, "name", "asc");
    }

    @GetMapping("/new")
    public String add(Model model)
    {
        Task temporaryTask = new Task();
        model.addAttribute("task", temporaryTask);
        model.addAttribute("status", temporaryTask.getStatus());
        model.addAttribute("missionList", missionService.listAll());
        model.addAttribute("workerList", workerService.listAll());
        model.addAttribute("itemList", itemService.listAll());
        return "panel/task/add-task";
    }

    @PostMapping("/save")
    public String save(Task task)
    {
        service.addTask(task);
        return path;
    }

    @RequestMapping("/description/{id}")
    public String describe(@PathVariable(name = "id") Long id, Model model)
    {
        String description = service.getDescription(id);
        model.addAttribute("missionDescription", description);
        return "panel/task/task-details";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") Long id, Model model, RedirectAttributes redirectAttributes)
    {
        try {
        repository.deleteById(id);
        return "user/edit-users";

    }   catch(Exception ex)

    {
        redirectAttributes.addFlashAttribute(("message"), ex.getMessage());
        return "redirect:/ user/edit-users";
    }
    }



}
