package bartus.jakub.area27.enums;

public enum WorkShift {
    RANO,POPOLUDNIE,NOC
}
