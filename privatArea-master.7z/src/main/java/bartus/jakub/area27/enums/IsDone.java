package bartus.jakub.area27.enums;


import lombok.Getter;

@Getter
public enum IsDone {
    Done("DONE"),In_Progress("In_Progress"),PLANNING("PLANNING");
IsDone(String s) {
    }
}
