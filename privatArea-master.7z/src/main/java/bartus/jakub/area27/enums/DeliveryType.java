package bartus.jakub.area27.enums;

import lombok.Getter;

@Getter
public enum DeliveryType {
    IN("IN"),OUT("OUT");
    DeliveryType(String s)
    {

    }
}
