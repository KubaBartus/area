package bartus.jakub.area27.role;


import bartus.jakub.area27.configuration.PagingAndSorting;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleService implements PagingAndSorting {

    private RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository)
    {
        this.roleRepository = roleRepository;
    }

    public List<Role> listAllRoles()
    {
        return (List<Role>) roleRepository.findAll();
    }

    public void rolesAdd()
    {
        Role role1 = new Role(1,"Pracownik","Stopien uprawnien = 1");
        Role role2 = new Role(2,"Manager","Stopien uprawnien = 2");
        Role role3 = new Role(3,"Specjalista","Stopien uprawnien = 3");
        Role role4 = new Role(4,"Administrator","Stopien uprawnien = 4");
        Role role5 = new Role(5,"Dyrektor","Stopien uprawnien = 5");
        List<Role> roles = new ArrayList<>();
        roles.add(role1);
        roles.add(role2);
        roles.add(role3);
        roles.add(role4);
        roles.add(role5);
        roleRepository.saveAll(roles);
    }

}
